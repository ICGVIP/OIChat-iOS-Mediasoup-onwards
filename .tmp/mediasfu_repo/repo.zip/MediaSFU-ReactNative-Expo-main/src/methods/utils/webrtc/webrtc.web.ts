import {
  RTCView, MediaStream, mediaDevices, registerGlobals, MediaStreamTrack,
} from 'react-native-webrtc-web-shim';

export {
  RTCView, mediaDevices, registerGlobals, MediaStream, MediaStreamTrack,
};
